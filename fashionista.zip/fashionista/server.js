// Use Express
var express = require("express");
// Use body-parser
var bodyParser = require("body-parser");
// Use MongoDB
var mongodb = require("mongodb");
var ObjectID = mongodb.ObjectID;
// The database variable
var database;
// Collections
var PRODUCTS_COLLECTION = "products";
var USERS_COLLECTION = "users";
var SHOPPING_COLLECTION = "shopping";
var WISHLIST_COLLECTION = "wishList";
var PURCHASED_COLLECTION = "purchased";
// Create new instance of the express server
var app = express();

// Define the JSON parser as a default way 
// to consume and produce data through the 
// exposed APIs
app.use(bodyParser.json());

// Create link to Angular build directory
// The `ng build` command will save the result
// under the `dist` folder.
var distDir = __dirname + "/dist/";
app.use(express.static(distDir));

// Local database URI.
const LOCAL_DATABASE = "mongodb+srv://matthew:matt123@cluster0.kece5.mongodb.net/chatapp?retryWrites=true&w=majority";
// Local port.
const LOCAL_PORT = 8080;

// Init the server
mongodb.MongoClient.connect(process.env.MONGODB_URI || LOCAL_DATABASE,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    }, function (error, client) {

        // Check if there are any problems with the connection to MongoDB database.
        if (error) {
            console.log(error);
            process.exit(1);
        }

        // Save database object from the callback for reuse.
        database = client.db();
        console.log("Database connection done.");

        // Initialize the app.
        var server = app.listen(process.env.PORT || LOCAL_PORT, function () {
            var port = server.address().port;
            console.log("App now running on port", port);
        });
    });

/*  "/api/status"
 *   GET: Get server status
 *   PS: it's just an example, not mandatory
 */
app.get("/api/status", function (req, res) {
    res.status(200).json({ status: "UP" });
});

/*  "/api/products"
 *  GET: finds all products
 */
app.get("/api/products", function (req, res) {
    database.collection(PRODUCTS_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

/*  "/api/products"
 *   POST: creates a new product
 */
app.post("/api/products", function (req, res) {
    var product = req.body;

    if (!product.name) {
        manageError(res, "Invalid product input", "Name is mandatory.", 400);
    } else if (!product.brand) {
        manageError(res, "Invalid product input", "Brand is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTION).insertOne(product, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new product.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});

/*  "/api/products/:id"
 *   DELETE: deletes product by id
 */
app.delete("/api/products/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid product id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTION).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete product.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});

/*  "/api/products/:id"
 *   put: updates product by id
 */
app.put("/api/products/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid product id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTION).updateOne({ _id: new ObjectID(req.params.id)}, {$set: {name: req.body.name, brand: req.body.brand, stock: req.body.stock, price: req.body.price}}, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to update user.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});

/*  "/api/users"
 *  GET: finds all users
 */
app.get("/api/users", function (req, res) {
    database.collection(USERS_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

/*  "/api/users"
 *   POST: creates a new user
 */
app.post("/api/users", function (req, res) {
    var user = req.body;

    if (!user.name) {
        manageError(res, "Invalid user input", "Name is mandatory.", 400);
    } else if (!user.email) {
        manageError(res, "Invalid user input", "Email is mandatory.", 400);
    } else if (!user.password) {
        manageError(res, "Invalid user input", "password is mandatory.", 400);
    }else {
        database.collection(USERS_COLLECTION).insertOne(user, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new user.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});

/*  "/api/users/:id"
 *   DELETE: deletes user by id
 */
app.delete("/api/users/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid user id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(USERS_COLLECTION).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to update user.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});

/*  "/api/users/:id"
 *   put: updates user by id
 */
app.put("/api/users/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid user id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(USERS_COLLECTION).updateOne({ _id: new ObjectID(req.params.id)}, {$set: {name: req.body.name, email: req.body.email, password: req.body.password}}, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to update user.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});

/*  "/api/shopping"
 *  GET: finds all products in the shopping cart
 */
app.get("/api/shopping", function (req, res) {
    database.collection(SHOPPING_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

/*  "/api/shopping"
 *   POST: Add to shopping cart
 */
app.post("/api/shopping", function (req, res) {
    var product = req.body;
    database.collection(SHOPPING_COLLECTION).insertOne(product, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to add to the shopping cart.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
});

/*  "/api/shopping"
 *   DELETE: deletes all entries
 */
app.delete("/api/shopping", function (req, res) {
    database.collection(SHOPPING_COLLECTION).deleteMany({}, function (err, result) {
        if (err) {
            manageError(res, err.message, "Failed to update user.");
        } else {
            res.status(200).json(req.params.id);
        }
    });
});

/*  "/api/wishList"
 *  GET: finds all products in the Wish List Cart cart
 */
app.get("/api/wishList", function (req, res) {
    database.collection(WISHLIST_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

/*  "/api/wishList"
 *   POST: Add to Wish List cart
 */
app.post("/api/wishList", function (req, res) {
    var product = req.body;
    database.collection(WISHLIST_COLLECTION).insertOne(product, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to add to the Wish List Cart.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
});

/*  "/api/purchased"
 *  GET: finds all products purchased
 */
app.get("/api/purchased", function (req, res) {
    database.collection(PURCHASED_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

/*  "/api/purchased"
 *   POST: Add to purchased
 */
app.post("/api/purchased", function (req, res) {
    var product = req.body;
    database.collection(PURCHASED_COLLECTION).insertOne(product, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to add to purchased.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
});

// Errors handler.
function manageError(res, reason, message, code) {
    console.log("Error: " + reason);
    res.status(code || 500).json({ "error": message });
}