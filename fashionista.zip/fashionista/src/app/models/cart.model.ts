import { Product } from './product.model';

export interface ICart {
    _id?: string;
    cart: any;
}

export class shopping implements ICart  {
    constructor(public cart: Product, public _id?: string){
        this._id = _id ? _id : null;
        this.cart = cart;
    }
}

export class wishList implements ICart  {
    constructor(public cart: Product, public _id?: string){
        this._id = _id ? _id : null;
        this.cart = cart;
    }
}
  
 