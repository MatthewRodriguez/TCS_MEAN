import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { ProductCreateComponent } from './product/product-create/product-create.component';
import { ProductListComponent } from './product/product-list/product-list.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MyRouting } from './router/router.module';
import { ShoppingCartComponent } from './carts/shopping-cart/shopping-cart.component';
import { WishListCartComponent } from './carts/wish-list-cart/wish-list-cart.component';
import { UserComponent } from './users/user/user.component';
import { UserListComponent } from './users/user-list/user-list.component';
import { RegisterComponent } from './users/register/register.component';
import { ProductCustomerComponent } from './product/product-customer/product-customer.component';
import { HomePageComponent } from './home-page/home-page.component';
import { LoginComponent } from './users/login/login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { PurchasedComponent } from './carts/purchased/purchased.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductCreateComponent,
    ProductListComponent,
    ShoppingCartComponent,
    WishListCartComponent,
    UserComponent,
    UserListComponent,
    RegisterComponent,
    ProductCustomerComponent,
    HomePageComponent,
    LoginComponent,
    AdminHomeComponent,
    UserHomeComponent,
    PurchasedComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    MyRouting
  ],
  providers: [],
  // bootstrap: [AppComponent]
  bootstrap: [HomePageComponent]
})
export class AppModule { }