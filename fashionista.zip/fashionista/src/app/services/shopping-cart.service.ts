import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { IProduct, Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartService {
  private shopCartUrl = '/api/shopping';

  constructor(private http: Http) { }

  // Add a product to the shopping cart
  toCart(product: Product): Promise<IProduct> {
  return this.http.post(this.shopCartUrl, product)
      .toPromise()
      .then(response => response.json())
      .catch(this.error);
  }

  // Get products on Shopping Cart
  getShoppingCart(): Promise<Array<IProduct>> {
      return this.http.get(this.shopCartUrl)
          .toPromise()
          .then(response => response.json())
          .catch(this.error);
  }

  // Delete a user
  delete(): Promise<any> {
    return this.http.delete(`${this.shopCartUrl}`)
        .toPromise()
        .then(response => response.json())
        .catch(this.error);
  }

  // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}
