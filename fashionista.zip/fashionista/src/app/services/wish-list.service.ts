import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { IProduct, Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class WishListService {
  private wishListUrl = '/api/wishList';

  constructor(private http: Http) { }

  // Add a product to the shopping cart
  toWishCart(product: Product): Promise<IProduct> {
  return this.http.post(this.wishListUrl, product)
      .toPromise()
      .then(response => response.json())
      .catch(this.error);
  }

  // Get products on Shopping Cart
  getWishList(): Promise<Array<IProduct>> {
      return this.http.get(this.wishListUrl)
          .toPromise()
          .then(response => response.json())
          .catch(this.error);
  }

  // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}
