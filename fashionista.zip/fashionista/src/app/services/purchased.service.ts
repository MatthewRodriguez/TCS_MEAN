import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { IProduct, Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class PurchasedService {
  private purchasedUrl = '/api/purchased';
   
  constructor(private http: Http) { }

  // Get products
  get(): Promise<Array<IProduct>> {
    return this.http.get(this.purchasedUrl)
        .toPromise()
        .then(response => response.json())
        .catch(this.error);
  }

  // Create product
  addToPurchased(product: Product): Promise<IProduct> {
    return this.http.post(this.purchasedUrl, product)
        .toPromise()
        .then(response => response.json())
        .catch(this.error);
  }

  // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}
