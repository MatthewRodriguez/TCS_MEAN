import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../services/users.service';
import { IUser, User } from '../../models/user.model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  email: string = '';
  password: string = '';

  constructor(protected formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.initForm();
  }

  onSubmit(){
    if (this.loginForm.value['email'] === "admin@mail.com" && this.loginForm.value['password'] === "12345"){
      this.router.navigate(["product/product-create"])
    } else{
      this.router.navigate(["product/product-customer"])
    }
  }

  // Init the creation form.
  private initForm() {
    this.loginForm = new FormGroup({
      email: new FormControl(this.email, Validators.required),
      password: new FormControl(this.password, Validators.required)
    });
  }

}
