import { Component, OnChanges, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UsersService } from '../../services/users.service';
import { IUser, User } from '../../models/user.model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit, OnChanges {

  users: Array<IUser> = [];
  view: boolean = true;
  userForm: FormGroup;
  name: string = '';
  email: string = '';
  password: string = '';
  id: string = '';

  @Input() usersToDisplay: IUser = null;
  // @Output() createdUser = new EventEmitter<IUser>();

  constructor(protected userService: UsersService, protected formBuilder: FormBuilder) { }

  // Load all the users when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new user created, we add it to the list.
  ngOnChanges(): void {
    if (this.usersToDisplay !== null) {
      this.users.push(this.usersToDisplay);
    }
  }

  // Delete a user. 
  delete(id: string) {
    this.userService.delete(id).then((result: any) => this.loadAll());
  }

  // Update a user. 
  update(uid: string, user: User) {
    this.view = false;
    this.id = uid;
    this.initForm();
  }

  // Load all users.
  private loadAll() {
    this.userService
      .get()
      .then((result: Array<IUser>) => {
        this.users = result;
      });
  }

  // Manage the submit action and create the new user.
  onSubmit() {
    this.view = true;
    const user = new User(this.userForm.value['name'], this.userForm.value['email'], this.userForm.value['password'], null);
    this.userService.update(this.id, user).then((result: any) => this.loadAll());
  }

  // Init the creation form.
  private initForm() {
    this.userForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      email: new FormControl(this.email, Validators.required),
      password: new FormControl(this.password, Validators.required)
    });
  }
}
