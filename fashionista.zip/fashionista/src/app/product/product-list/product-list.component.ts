import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { IProduct, Product } from '../../models/product.model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit, OnChanges {

  products: Array<IProduct> = [];
  view: boolean = true;
  productForm: FormGroup;
  name: string = '';
  brand: string = '';
  stock: string = '';
  price: string = '';
  id: string = '';
  @Input() productToDisplay: IProduct = null;

  constructor(protected productService: ProductService) { }

  // Load all the products when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new product created, we add it to the list.
  ngOnChanges(): void {
    if (this.productToDisplay !== null) {
      this.products.push(this.productToDisplay);
    }
  }

  // Delete a product. 
  delete(id: string) {
    this.productService.delete(id).then((result: any) => this.loadAll());
  }

  // Update a product. 
  update(pid: string) {
    this.view = false;
    this.id = pid;
    this.initForm();
  }

  // Load all products.
  private loadAll() {
    this.productService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }

   // Manage the submit action and create the new product.
   onSubmit(id: string) {
    this.view = true;
    const product = new Product(this.productForm.value['name'], this.productForm.value['brand'], this.productForm.value['stock'], this.productForm.value['price'], null);
    this.productService.update(this.id, product).then((result: any) => this.loadAll());
  }

  // Init the creation form.
  private initForm() {
    this.productForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      brand: new FormControl(this.brand, Validators.required),
      stock: new FormControl(this.stock, Validators.required),
      price: new FormControl(this.price, Validators.required)
    });
  }
}
