import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ShoppingCartService } from '../../services/shopping-cart.service';
import { WishListService } from '../../services/wish-list.service';
import { ProductService } from '../../services/product.service';
import { IProduct, Product } from '../../models/product.model';

@Component({
  selector: 'app-product-customer',
  templateUrl: './product-customer.component.html',
  styleUrls: ['./product-customer.component.css']
})
export class ProductCustomerComponent implements OnInit, OnChanges {

  products: Array<IProduct> = [];
  @Input() productToDisplay: IProduct = null;

  constructor(protected shopService: ShoppingCartService, protected wishService: WishListService, protected productService: ProductService) { }

  // Load all the products when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new product created, we add it to the list.
  ngOnChanges(): void {
    if (this.productToDisplay !== null) {
      this.products.push(this.productToDisplay);
    }
  }

  // Add a product to the shopping cart. 
  addToCart(product: Product) {
    this.shopService.toCart(product).then((result: any) => this.loadAll());
  }

  // Add a product to the shopping cart. 
  addToWishList(product: Product) {
    this.wishService.toWishCart(product).then((result: any) => this.loadAll());
  }

  // Load all products.
  private loadAll() {
    this.productService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }
}
