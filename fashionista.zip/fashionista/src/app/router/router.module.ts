import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProductCreateComponent } from '../product/product-create/product-create.component';
import { ProductListComponent } from '../product/product-list/product-list.component';
import { UserComponent } from '../users/user/user.component';
import { UserListComponent } from '../users/user-list/user-list.component';
import { RegisterComponent } from '../users/register/register.component';
import { ProductCustomerComponent } from '../product/product-customer/product-customer.component';
import { ShoppingCartComponent } from '../carts/shopping-cart/shopping-cart.component';
import { WishListCartComponent } from '../carts/wish-list-cart/wish-list-cart.component';
import { LoginComponent } from '../users/login/login.component';
import { UserHomeComponent } from '../user-home/user-home.component';
import { AdminHomeComponent } from '../admin-home/admin-home.component';
import { PurchasedComponent } from '../carts/purchased/purchased.component';
 
// @NgModule({
//   declarations: [],
//   imports: [
//     CommonModule
//   ]
// })
export const MyRouting=RouterModule.forRoot([
  {path:'product/product-create', component:ProductCreateComponent},
  {path:'product/product-list', component:ProductListComponent},
  {path:'users/user', component:UserComponent},
  {path:'users/user-list', component:UserListComponent},
  {path:'users/register', component:RegisterComponent},
  {path:'product/product-customer', component:ProductCustomerComponent},
  {path:'carts/shopping-cart', component:ShoppingCartComponent},
  {path:'carts/wish-list-cart', component:WishListCartComponent},
  {path:'users/login', component:LoginComponent},
  {path:'user-home', component:UserHomeComponent},
  {path:'admin-home', component:AdminHomeComponent},
  {path:'carts/purchased', component:PurchasedComponent}
]) 