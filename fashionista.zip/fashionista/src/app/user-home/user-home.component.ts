import { Component, OnInit } from '@angular/core';
import { HomePageComponent } from '../home-page/home-page.component'

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {
  
  constructor(private home: HomePageComponent) { }

  ngOnInit(): void {
    this.home.home = false;
  }

  onClick(){
    
  }

}
