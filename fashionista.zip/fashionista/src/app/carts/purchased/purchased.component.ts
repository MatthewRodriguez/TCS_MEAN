import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { PurchasedService } from '../../services/purchased.service';
import { IProduct, Product } from '../../models/product.model';


@Component({
  selector: 'app-purchased',
  templateUrl: './purchased.component.html',
  styleUrls: ['./purchased.component.css']
})
export class PurchasedComponent implements OnInit, OnChanges {

  products: Array<IProduct> = [];
  @Input() productToDisplay: IProduct = null;
  constructor(protected purchasedService: PurchasedService) { }

  ngOnInit(): void {
    this.loadAll();
  }

  // If new product created, we add it to the list.
  ngOnChanges(): void {
    if (this.productToDisplay !== null) {
      this.products.push(this.productToDisplay);
    }
  }


  // Load all products.
  private loadAll() {
    this.purchasedService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }
}
