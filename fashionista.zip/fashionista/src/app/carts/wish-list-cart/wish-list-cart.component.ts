import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { WishListService } from '../../services/wish-list.service';
import { IProduct, Product } from '../../models/product.model';

@Component({
  selector: 'app-wish-list-cart',
  templateUrl: './wish-list-cart.component.html',
  styleUrls: ['./wish-list-cart.component.css']
})
export class WishListCartComponent implements OnInit, OnChanges {

  products: Array<IProduct> = [];
  message: boolean = false;
  @Input() productToDisplay: IProduct = null;

  constructor(protected cartService: WishListService) { }

  // Load all the products when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new product created, we add it to the list.
  ngOnChanges(): void {
    if (this.productToDisplay !== null) {
      this.products.push(this.productToDisplay);
    }
  }

  // Add a product to the shopping cart. 
  addToCart(product: Product) {
    this.cartService.toWishCart(product).then((result: any) => this.message = true);
  }

  // Message
  private hide(){
    this.message = false;
  }

  // Load all products.
  private loadAll() {
    this.cartService
      .getWishList()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }
}
