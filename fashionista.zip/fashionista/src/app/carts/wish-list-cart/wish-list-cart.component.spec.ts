import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WishListCartComponent } from './wish-list-cart.component';

describe('WishListCartComponent', () => {
  let component: WishListCartComponent;
  let fixture: ComponentFixture<WishListCartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WishListCartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WishListCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
