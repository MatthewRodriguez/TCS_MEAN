import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ShoppingCartService } from '../../services/shopping-cart.service';
import { PurchasedService } from '../../services/purchased.service';
import { IProduct, Product } from '../../models/product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit, OnChanges {

  products: Array<IProduct> = [];
  message: boolean = false;
  @Input() productToDisplay: IProduct = null;

  constructor(protected cartService: ShoppingCartService, protected purchasedService: PurchasedService, protected router: Router) { }

  // Load all the products when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new product created, we add it to the list.
  ngOnChanges(): void {
    if (this.productToDisplay !== null) {
      this.products.push(this.productToDisplay);
    }
  }

  // Add a product to the shopping cart. 
  addToCart(product: Product) {
    this.cartService.toCart(product).then((result: any) => this.message = true);
  }

  onSubmit(){
    this.products.forEach(product => {
      this.purchasedService.addToPurchased(product).then((result: any) => this.message = true);
    });
    this.cartService.delete().then((result: any) => this.message = true);
    this.router.navigate(["carts/purchased"])
  }

  // Message
  private hide(){
    this.message = false;
  }

  // Load all products.
  private loadAll() {
    this.cartService
      .getShoppingCart()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }
}
